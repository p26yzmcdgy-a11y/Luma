# Luma prototype — iPhone offline app

## What it does
A local-first, installable iPhone prototype with Home, Create, Explore, and Insights.

## Does it save data?
Yes. Project metadata is stored in `localStorage`; imported photos are stored inside the saved project as local data URLs. Nothing in this prototype sends your photos to a server or uses a paid API.

Important: browser/site data can be deleted by iOS/Safari, and this prototype does not yet have cloud backup. If you delete the website's data, the saved projects can be lost.

## Free iPhone installation
1. Put this folder on a free static host such as GitHub Pages or Cloudflare Pages.
2. Open the HTTPS URL in Safari on your iPhone.
3. Tap Share -> Add to Home Screen.
4. Launch Luma from the Home Screen.
5. Open it once while online so the service worker caches the app. After that, the app shell works offline.

The hosting account is only used to deliver the app files; the prototype itself does not upload your project data.

## Local development
Serve this directory over HTTP/HTTPS (not `file://`) because service workers require a web origin.
